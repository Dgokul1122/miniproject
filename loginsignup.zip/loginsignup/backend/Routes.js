const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const connection = require('./database'); 


router.post('/register', async (req, res) => {
  const { name, email, password, dob, empId } = req.body;

  try {
    // Hashing the password 
    const hashedPassword = await bcrypt.hash(password, 10);

    // Inserting user details into the users table
    const sql = 'INSERT INTO users (empId, name, email, password, dob) VALUES (?, ?, ?, ?, ?)';
    connection.query(sql, [empId, name, email, hashedPassword, dob], (error, results) => {
      if (error) {
        console.error(error);
        res.status(500).json({ message: 'Error registering user' });
      } else {
        res.status(200).json({ message: 'User registered successfully' });
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'An error occurred during registration' });
  }
});

// Route for user login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const sql = 'SELECT * FROM users WHERE email = ?';
    connection.query(sql, [email], async (error, results) => {
      if (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching user details' });
      } else {
        if (results.length === 0) {
          res.status(404).json({ message: 'User not found' });
        } else {
          const user = results[0];
          const passwordMatch = await bcrypt.compare(password, user.password);
          if (passwordMatch) {
            res.status(200).json({ message: 'Login successful', empId: user.empId });
          } else {
            res.status(401).json({ message: 'Invalid email or password' });
          }
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'An error occurred during login' });
  }
});

// fetching user details based on empId
router.get('/userdetails/:empdId', async (req, res) => {
  const userId = req.params.userId;

  try {
    const userDetails = await db.getUserDetailsById(userId); 
    if (userDetails) {
      res.json(userDetails);
    } else {
      res.status(404).json({ error: 'User details not found' });
    }
  } catch (error) {
    console.error('Error fetching user details:', error);
    res.status(500).json({ error: 'An error occurred while fetching user details' });
  }
});







// app.get('/api/birthdays', (req, res) => {
//   // Query the database to fetch names and dates of birth
//   // Replace this query with the appropriate query to fetch the data from your database
//   const query = 'SELECT name, dob FROM users';
//   db.query(query, (error, results) => {
//     if (error) {
//       console.error('Error fetching birthdays:', error);
//       res.status(500).json({ error: 'An error occurred' });
//     } else {
//       res.json(results);
//     }
//   });
// });



module.exports = router;
