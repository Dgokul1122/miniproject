const express = require('express');
const userRoutes = require('./Routes'); 
const cors = require('cors');
const app = express();
app.use(cors())

app.use(express.json());
app.use('/api', userRoutes); 
app.use('/api/register',userRoutes);
app.use('/api/userdetails',userRoutes);

app.listen(4000, () => {
  console.log('Server is running on port 4000');
});
