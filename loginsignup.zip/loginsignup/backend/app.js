const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const usersRoute = require('./Routes'); // Import your users route

const app = express();

app.use(cors());
app.use(bodyParser.json());

// Use the users route
app.use('/api/register', usersRoute);

const port = process.env.PORT || 3001;

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
