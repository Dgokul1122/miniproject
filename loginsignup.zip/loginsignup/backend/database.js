const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'SQLpassword',
  database: 'mini_project',
});

module.exports = connection;
