import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LandingPage from './components/FirstPage';
import LoginPage from './components/Login';
import SignupPage from './components/signup';
import Dashboard from './components/Dashboard';
import UserDetails from './components/UserDetails';
import CreateEventPage from './components/eventForm';
import './App.css';

const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/userdetails/:empId" element={<UserDetails />} />
        <Route path="/eventForm" element={<CreateEventPage />} />
      </Routes>
    </Router>
  );
};

export default App;
