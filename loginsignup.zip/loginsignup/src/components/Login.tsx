import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './css/login.css';

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error] = useState<string | null>(null);

  const handleLogin = async () => {
    axios.defaults.baseURL = 'http://localhost:4000';
    axios
      .post('/api/login', { email, password })
      .then((response) => {
        if (response.status === 200) {
          navigate('/dashboard');
        } else {
          alert('Invalid credentials');
        }
      })
      .catch((error) => {
        console.error('Error during login:', error);
        alert('Please fill the details');
      });
    };
  return (
    <>
    <div className='login'>
    <div className="login-container">
      <h2>Login</h2>
      <div>
        <label>Email:</label>
        <input className="login-input" type="text" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <label>Password:</label>
        <input className="login-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      <button className="login-button" onClick={handleLogin}>
        Login
      </button>
      {error && <p className="error-message">{error}</p>}
    </div>
    </div>
    </>
    
  );
    

};

export default LoginPage;
