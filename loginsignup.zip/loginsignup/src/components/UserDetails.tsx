import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { UserDetails } from './details';

interface UserDetailsProps {
  userDetails: UserDetails | null;
}

const UserDetailsComponent: React.FC<UserDetailsProps> = ({ userDetails }) => {
  if (!userDetails) {
    return <div>No user details found.</div>;
  }

  return (
    <div>
      <h2>User Details</h2>
      <p>Name: {userDetails.name}</p>
      <p>Email: {userDetails.email}</p>
      <p>DOB: {userDetails.dob}</p>
      <p>EmpID: {userDetails.empId}</p>
    </div>
  );
};

const UserDetailsPage: React.FC = () => {
  const [userDetails, setUserDetails] = useState<UserDetails | null>(null);

  useEffect(() => {
    // Make an API request to fetch user details
    axios.get(`/api/userdetails`) 
      .then((response) => {
        setUserDetails(response.data);
      })
      .catch((error) => {
        console.error('Error fetching user details:', error);
      });
  }, []);

  return (
    <div>
      <UserDetailsComponent userDetails={userDetails} />
    </div>
  );
};

export default UserDetailsPage;
