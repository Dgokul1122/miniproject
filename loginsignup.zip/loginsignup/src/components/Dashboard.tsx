import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './css/dashboard.css';

const Dashboard: React.FC = () => {
  const location = useLocation();
  const userDetails = location.state;

  const navigate = useNavigate();

  
  const handleUserDetailsClick = () => {
    const empId = userDetails;
    navigate(`/api/userdetails/${empId}`);
  };
 
  const handleNewEventClick =() =>{
    navigate("/eventForm")
  }
  return (
    <>
    <div className='main'>
    <div className="sidenav">
       <a className='icon'><img src={require('../images/jin_logo.png')} alt="Logo" /></a>
      <button className='btn' >Holidays</button>
      <button className='btn'>
        Birthdays
      </button>
      <button className='btn'>Official Events</button>
      <button className='btn'>Leave</button>
      <button className="newevent"onClick={handleNewEventClick}>+ New Event</button>
      <p id="footer">
        Gokul&nbsp;&nbsp;<button className='profile' onClick={handleUserDetailsClick}>Profile</button>
      </p>
    </div>
    <div>
    <a className='dash'><img src={require('../images/images1997.jpg')} alt="Logo" /></a>
    </div>
    </div>
    
    </>  
  );
};

export default Dashboard;
