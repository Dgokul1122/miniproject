import React, { useState } from 'react';
import axios from 'axios';
import './css/signupform.css';
import { UserDetails } from './details';

interface SignupFormProps {
  onSignup: (details: UserDetails) => void;
  navigate: (path: string) => void;
}

const SignupForm: React.FC<SignupFormProps> = ({ onSignup, navigate }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [dob, setDOB] = useState('');
  const [empId, setEmpId] = useState('');

  const handleSignup = async () => {
    if (!name || !email || !password || !dob || !empId) {
      alert('Please fill in all fields.');
    } else {
      const userDetails: UserDetails = { name, email, dob, empId, password };

      try {
        const response = await axios.post('/api/register', userDetails);

        if (response.status === 200) {
          onSignup(userDetails);
          navigate('/dashboard');
        } else {
          alert('Error registering user');
        }
      } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during registration.');
      }
    }
  };

  return (
    <>
    <div className='signup'>
    <div className="signup-form-container">
      <h2>Signup</h2>
      <div className="input-container">
        <label>Name:</label>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
      </div>
      <div className="input-container">
        <label>Email:</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div className="input-container">
        <label>Password:</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      <div className="input-container">
        <label>Date of Birth:</label>
        <input type="date" value={dob} onChange={(e) => setDOB(e.target.value)} />
      </div>
      <div className="input-container">
        <label>Employee ID:</label>
        <input type="text" value={empId} onChange={(e) => setEmpId(e.target.value)} />
      </div>
      <button className="signup-button" onClick={handleSignup}>
        Sign Up
      </button>
    </div>
    </div>
    
    </>
    
  );
};

export default SignupForm;
