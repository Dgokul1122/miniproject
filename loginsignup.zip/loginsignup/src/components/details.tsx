
export interface UserDetails {
  name: string;
  email: string;
  dob: string;
  empId: string; 
  password: string;
}

  