

import React from 'react';
import { Link } from 'react-router-dom';
import './css/firstPage.css'; 

const FirstPage: React.FC = () => {
  return (
    <div className="first-page-container">
      <div className="image-container">
        <img className="image" src={require('../images/main.png')} alt="App Logo" />
      </div>
      <div className="button-container">
        <p className='tname'>Welcome to JIN</p>
        <h2>Already a user?</h2>
        <Link to="/login" className="button">
          <h2>Login</h2>
        </Link>
        <h2>New User</h2>
        <Link to="/signup" className="button">
          <h2>Signup</h2>
        </Link>
      </div>
      
    </div>
    
  );
};

export default FirstPage;

