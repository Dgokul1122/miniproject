import React, { useState } from 'react';
import axios from 'axios';
import './css/eventForm.css'

const CreateEventPage: React.FC = () => {
  const [eventName, setEventName] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventDescription, setEventDescription] = useState('');

  const handleCreateEvent = async () => {
    
    const eventDetails = {
      eventName,
      eventDate,
      eventDescription,
    };

    try {
      
      const response = await axios.post('/api/create-event', eventDetails);

      if (response.status === 201) {
        alert('Event created successfully');
      } else {
        alert('Error creating event');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred during event creation.');
    }
  };

  return (
    <div className="create-event-container">
      <h2>Create New Event</h2>
      <div className="input-container">
        <label>Event Name:</label>
        <input  type="text" value={eventName} onChange={(e) => setEventName(e.target.value)} />
      </div>
      <div className="eventdate">
        <label>Event Date:</label>
        <input type="date" value={eventDate} onChange={(e) => setEventDate(e.target.value)} />
      </div>
      <div className="des">
        <label>Event Description:</label>
        <textarea value={eventDescription} onChange={(e) => setEventDescription(e.target.value)} />
      </div>
      <button className="create-event-button" onClick={handleCreateEvent}>
        Create Event
      </button>
    </div>
  );
};

export default CreateEventPage;
