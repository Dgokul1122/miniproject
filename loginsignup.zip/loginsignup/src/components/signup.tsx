import React from 'react';
import SignupForm from './SignupForm';
import axios from 'axios'; 
import { UserDetails } from './details'; 
import { useNavigate } from 'react-router-dom';

const SignupPage: React.FC = () => {
  const navigate = useNavigate();

  const handleSignup = async (details: UserDetails) => {
    try {
      const response = await axios.post('/api/register', details);

      if (response.status === 200) {
        navigate('/dashboard');
      } else {
        alert('Error registering user');
      }
    } catch (error) {
      console.error('Error:', error);
      
    }
  };

  return (
    <div>
      <SignupForm onSignup={handleSignup} navigate={navigate} />
    </div>
  );
};

export default SignupPage;
